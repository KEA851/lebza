# Lebo Security website

## Open
- [ ] Replace placeholder contact details (phone, email, region) with the real ones from Lebo Security
- [ ] Confirm sender email domain (needs a domain Lebo owns) before emails can go out
- [ ] Grant the admin role to the business owner's account

## In progress
- [ ] Shared header/footer with live sign-in state (site chrome)
- [ ] Admin activity log: sign-ins, quote status changes, account actions with timestamps

## Done
- [x] Design direction: charcoal & ember, Libre Baskerville + IBM Plex Sans, hero + service cards
- [x] Site photos generated and wired into pages
- [x] Service-focused layout: guarding, CCTV installation, access control, alarm response + supporting services
- [x] Quote form with name, contact details, service type, message + client-side validation
- [x] Loading state + disabled submit button to prevent duplicate submissions
- [x] Quote requests stored in the database (duplicate-safe, follow-up fields)
- [x] Business notification + submitter confirmation emails sent from the quote flow, with retry-safe resend
- [x] Admin sign-in (email + Google) protecting the quote inbox, with role checked on every request
- [x] Secure password reset: reset link request + new-password page
- [x] Pages: home, services, about, contact
- [x] Per-page metadata + favicon

## Notes
- Emails stay queued on the request record until a sender domain is verified; the admin page can re-send them.
- Admin rights are granted by the team only — no self-assignment.
