CREATE TABLE public.admin_activity (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id UUID,
  actor_email TEXT,
  action TEXT NOT NULL,
  detail TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.admin_activity TO authenticated;
GRANT ALL ON public.admin_activity TO service_role;

ALTER TABLE public.admin_activity ENABLE ROW LEVEL SECURITY;

CREATE POLICY admin_activity_admin_select
  ON public.admin_activity FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT, UPDATE, DELETE ON public.quote_requests TO service_role;
GRANT SELECT ON public.quote_requests TO authenticated;
GRANT SELECT ON public.user_roles TO authenticated;