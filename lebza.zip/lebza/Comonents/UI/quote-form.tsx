import { useState, type ChangeEvent, type FormEvent } from "react";
import { useServerFn } from "@tanstack/react-start";
import { SERVICES } from "@/lib/services";
import { submitQuoteRequest } from "@/lib/quote.functions";
import { cn } from "@/lib/utils";

type Fields = {
  name: string;
  company: string;
  email: string;
  phone: string;
  service: string;
  message: string;
};

const EMPTY: Fields = {
  name: "",
  company: "",
  email: "",
  phone: "",
  service: "",
  message: "",
};

const SERVICE_OPTIONS = [
  ...SERVICES.map((service) => service.title),
  "Not sure yet — advise me",
];

const labelClass =
  "block font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground";

const fieldClass =
  "mt-2 w-full border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-primary";

function errorClass(hasError: boolean) {
  return cn(fieldClass, hasError && "border-destructive");
}

function newKey() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

export function QuoteForm() {
  const send = useServerFn(submitQuoteRequest);
  const [fields, setFields] = useState<Fields>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof Fields, string>>>(
    {},
  );
  const [key, setKey] = useState(newKey);
  const [busy, setBusy] = useState(false);
  const [failure, setFailure] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<{
    reference: string;
    name: string;
    service: string;
    notice: string | null;
  } | null>(null);

  function update(keyName: keyof Fields) {
    return (
      event: ChangeEvent<
        HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
      >,
    ) => {
      const value = event.target.value;
      setFields((current) => ({ ...current, [keyName]: value }));
      setErrors((current) => ({ ...current, [keyName]: undefined }));
    };
  }

  function validate() {
    const next: Partial<Record<keyof Fields, string>> = {};
    if (!fields.name.trim()) next.name = "Please tell us who to reply to.";
    if (!fields.email.trim()) next.email = "An email address is needed.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim()))
      next.email = "That email doesn't look right.";
    if (!fields.phone.trim())
      next.phone = "A number we can reach you on, please.";
    if (!fields.service) next.service = "Pick the closest service.";
    if (fields.message.trim().length < 12)
      next.message = "A sentence or two about the site helps us quote.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFailure(null);
    if (!validate() || busy) return;

    setBusy(true);
    try {
      const result = await send({
        data: {
          requestKey: key,
          name: fields.name.trim(),
          company: fields.company.trim() || undefined,
          email: fields.email.trim(),
          phone: fields.phone.trim(),
          service: fields.service,
          message: fields.message.trim(),
        },
      });

      setReceipt({
        reference: result.reference,
        name: fields.name.trim(),
        service: fields.service,
        notice: result.emailNotice,
      });
      setFields(EMPTY);
      setKey(newKey());
    } catch {
      // Same request key is reused, so pressing send again can't double-log.
      setFailure(
        "We couldn't reach our servers just then. Your details are still here — press send again.",
      );
    } finally {
      setBusy(false);
    }
  }

  if (receipt) {
    return (
      <div className="border border-primary/40 bg-surface p-8">
        <p className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-primary">
          Request logged · {receipt.reference}
        </p>
        <h3 className="mt-4 text-2xl">
          Thanks {receipt.name.split(" ")[0]} — a supervisor will call you back.
        </h3>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          We have your details, your interest in{" "}
          <span className="text-foreground">
            {receipt.service.toLowerCase()}
          </span>{" "}
          and your notes. Expect a call within one working day, and a site visit
          booked before anything is quoted. A confirmation email is on its way
          to you.
        </p>
        {receipt.notice ? (
          <p className="mt-4 border border-border px-4 py-3 text-xs leading-relaxed text-muted-foreground">
            {receipt.notice}
          </p>
        ) : null}
        <button
          type="button"
          onClick={() => setReceipt(null)}
          className="mt-6 border border-border px-5 py-2.5 text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-foreground transition-colors hover:border-primary hover:text-primary"
        >
          Send another request
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="border border-border bg-surface p-6 sm:p-8"
    >
      <div className="grid gap-6 sm:grid-cols-2">
        <div>
          <label className={labelClass} htmlFor="quote-name">
            Full name
          </label>
          <input
            id="quote-name"
            className={errorClass(Boolean(errors.name))}
            value={fields.name}
            onChange={update("name")}
            placeholder="Thandi Mokoena"
            aria-invalid={Boolean(errors.name)}
          />
          {errors.name ? (
            <p className="mt-2 text-xs text-destructive">{errors.name}</p>
          ) : null}
        </div>
        <div>
          <label className={labelClass} htmlFor="quote-company">
            Company <span className="normal-case">(optional)</span>
          </label>
          <input
            id="quote-company"
            className={fieldClass}
            value={fields.company}
            onChange={update("company")}
            placeholder="Kasi Fresh Distributors"
          />
        </div>
        <div>
          <label className={labelClass} htmlFor="quote-email">
            Email
          </label>
          <input
            id="quote-email"
            type="email"
            className={errorClass(Boolean(errors.email))}
            value={fields.email}
            onChange={update("email")}
            placeholder="you@company.co.za"
            aria-invalid={Boolean(errors.email)}
          />
          {errors.email ? (
            <p className="mt-2 text-xs text-destructive">{errors.email}</p>
          ) : null}
        </div>
        <div>
          <label className={labelClass} htmlFor="quote-phone">
            Phone / WhatsApp
          </label>
          <input
            id="quote-phone"
            type="tel"
            className={errorClass(Boolean(errors.phone))}
            value={fields.phone}
            onChange={update("phone")}
            placeholder="+27 82 000 0000"
            aria-invalid={Boolean(errors.phone)}
          />
          {errors.phone ? (
            <p className="mt-2 text-xs text-destructive">{errors.phone}</p>
          ) : null}
        </div>
        <div className="sm:col-span-2">
          <label className={labelClass} htmlFor="quote-service">
            Service needed
          </label>
          <select
            id="quote-service"
            className={errorClass(Boolean(errors.service))}
            value={fields.service}
            onChange={update("service")}
            aria-invalid={Boolean(errors.service)}
          >
            <option value="">Choose a service…</option>
            {SERVICE_OPTIONS.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
          {errors.service ? (
            <p className="mt-2 text-xs text-destructive">{errors.service}</p>
          ) : null}
        </div>
        <div className="sm:col-span-2">
          <label className={labelClass} htmlFor="quote-message">
            What needs protecting?
          </label>
          <textarea
            id="quote-message"
            rows={5}
            className={errorClass(Boolean(errors.message))}
            value={fields.message}
            onChange={update("message")}
            placeholder="Two warehouses in Jet Park, fenced but lights fail after rain. We've had two break-ins this year and want an overnight officer plus camera cover."
            aria-invalid={Boolean(errors.message)}
          />
          {errors.message ? (
            <p className="mt-2 text-xs text-destructive">{errors.message}</p>
          ) : null}
        </div>
      </div>

      {failure ? (
        <p className="mt-6 border border-destructive/50 px-4 py-3 text-sm text-destructive">
          {failure}
        </p>
      ) : null}

      <div className="mt-8 flex flex-wrap items-center gap-4">
        <button
          type="submit"
          disabled={busy}
          className="bg-primary px-7 py-3 text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-primary-foreground transition-colors hover:bg-ember-glow disabled:cursor-not-allowed disabled:opacity-60"
        >
          {busy ? "Sending…" : "Request a quote"}
        </button>
        <p className="text-xs text-muted-foreground">
          {busy
            ? "Sending your request — this only takes a moment."
            : "No obligation. We reply within one working day."}
        </p>
      </div>
    </form>
  );
}
