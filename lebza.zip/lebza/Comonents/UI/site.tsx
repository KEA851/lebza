import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

const baseClass =
  "inline-flex items-center justify-center gap-2 px-6 py-3 text-[0.7rem] font-semibold uppercase tracking-[0.18em] transition-colors duration-200";

const solidClass = cn(
  baseClass,
  "bg-primary text-primary-foreground hover:bg-ember-glow",
);

const outlineClass = cn(
  baseClass,
  "border border-border text-foreground hover:border-primary hover:text-primary",
);

type To = "/" | "/services" | "/about" | "/contact";

export function EmberLink({
  to,
  children,
  className,
}: {
  to: To;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Link to={to} className={cn(solidClass, className)}>
      {children}
    </Link>
  );
}

export function OutlineLink({
  to,
  children,
  className,
}: {
  to: To;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Link to={to} className={cn(outlineClass, className)}>
      {children}
    </Link>
  );
}

export function Eyebrow({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <p
      className={cn(
        "flex items-center gap-3 font-mono text-[0.7rem] uppercase tracking-[0.24em] text-muted-foreground",
        className,
      )}
    >
      <span aria-hidden className="h-px w-8 bg-primary" />
      {children}
    </p>
  );
}

export function StatusPip({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className="border-l border-border pl-4">
      <p className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
        {label}
      </p>
      <p className="mt-1 text-sm text-foreground">{value}</p>
    </div>
  );
}

export function CheckRow({ children }: { children: ReactNode }) {
  return (
    <li className="flex gap-3 text-sm leading-relaxed text-muted-foreground">
      <span aria-hidden className="mt-[0.55rem] h-px w-4 shrink-0 bg-primary" />
      {children}
    </li>
  );
}
