import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

/**
 * Session-aware staff affordance. The header must never say "Staff sign in"
 * to someone who is already signed in, so this reads the live session.
 */
function useSessionUser() {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (active) setUser(data.session?.user ?? null);
    });
    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      if (active) setUser(session?.user ?? null);
    });
    return () => {
      active = false;
      data.subscription.unsubscribe();
    };
  }, []);

  return user;
}

function ShieldMark({ className = "h-7 w-7" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden
      className={className}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
    >
      <path d="M12 2.5 4.5 5.5v6c0 4.6 3.1 8.7 7.5 10 4.4-1.3 7.5-5.4 7.5-10v-6L12 2.5Z" />
      <path d="M8.7 12.2l2.3 2.3 4.4-4.5" />
    </svg>
  );
}

export function SiteHeader() {
  const user = useSessionUser();
  const pathname = useRouterState({
    select: (state) => state.location.pathname,
  });

  const links = [
    { to: "/services", label: "Services" },
    { to: "/about", label: "About" },
    { to: "/contact", label: "Contact" },
  ] as const;

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-6 py-4">
        <Link to="/" className="flex items-center gap-3">
          <span className="text-primary">
            <ShieldMark />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-lg text-foreground">
              Lebo Security
            </span>
            <span className="block font-mono text-[0.55rem] uppercase tracking-[0.24em] text-muted-foreground">
              Gauteng · 24/7
            </span>
          </span>
        </Link>

        <nav className="flex flex-wrap items-center gap-5">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`font-mono text-[0.65rem] uppercase tracking-[0.18em] transition-colors hover:text-primary ${
                pathname === link.to ? "text-primary" : "text-muted-foreground"
              }`}
            >
              {link.label}
            </Link>
          ))}
          <Link
            to="/contact"
            className="bg-primary px-4 py-2 font-mono text-[0.65rem] uppercase tracking-[0.18em] text-primary-foreground transition-colors hover:bg-ember-glow"
          >
            Request a quote
          </Link>
          {user ? (
            <Link
              to="/admin"
              className="font-mono text-[0.65rem] uppercase tracking-[0.18em] text-foreground transition-colors hover:text-primary"
            >
              Quote inbox
            </Link>
          ) : (
            <Link
              to="/auth"
              className="font-mono text-[0.65rem] uppercase tracking-[0.18em] text-muted-foreground transition-colors hover:text-primary"
            >
              Staff sign in
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const user = useSessionUser();

  return (
    <footer className="border-t border-border bg-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="flex items-center gap-2 font-display text-xl text-foreground">
            <span className="text-primary">
              <ShieldMark className="h-5 w-5" />
            </span>
            Lebo Security
          </p>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
            Guarding officers, CCTV installation, access control and alarm
            response for business and residential sites across Gauteng.
            Vetted officers, written reporting, one supervisor you can reach.
          </p>
        </div>

        <div>
          <p className="font-mono text-[0.6rem] uppercase tracking-[0.22em] text-muted-foreground">
            Services
          </p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <Link
                to="/services"
                className="text-foreground/90 transition-colors hover:text-primary"
              >
                All services
              </Link>
            </li>
            <li>
              <Link
                to="/about"
                className="text-foreground/90 transition-colors hover:text-primary"
              >
                How we work
              </Link>
            </li>
            <li>
              <Link
                to="/contact"
                className="text-foreground/90 transition-colors hover:text-primary"
              >
                Request a quote
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <p className="font-mono text-[0.6rem] uppercase tracking-[0.22em] text-muted-foreground">
            Contact
          </p>
          <ul className="mt-4 space-y-2 text-sm text-foreground/90">
            <li>
              <a
                href="tel:+27110000000"
                className="transition-colors hover:text-primary"
              >
                +27 11 000 0000
              </a>
            </li>
            <li>
              <a
                href="mailto:hello@lebosecurity.co.za"
                className="transition-colors hover:text-primary"
              >
                hello@lebosecurity.co.za
              </a>
            </li>
            <li className="text-muted-foreground">
              24/7 control room · Gauteng
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-6 py-5 font-mono text-[0.6rem] uppercase tracking-[0.18em] text-muted-foreground">
          <span>© {new Date().getFullYear()} Lebo Security</span>
          <span>PSRA registration pending</span>
          {user ? (
            <Link
              to="/admin"
              className="transition-colors hover:text-primary"
            >
              Quote inbox
            </Link>
          ) : (
            <Link to="/auth" className="transition-colors hover:text-primary">
              Staff
            </Link>
          )}
        </div>
      </div>
    </footer>
  );
}
