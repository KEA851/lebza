import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const submitShape = z.object({
  requestKey: z.string().min(8).max(64),
  name: z.string().trim().min(2, "Please tell us your name").max(120),
  company: z.string().trim().max(160).optional(),
  email: z.string().trim().email("Please enter a valid email address").max(200),
  phone: z.string().trim().min(6, "Please enter a phone number").max(40),
  service: z.string().trim().min(2, "Please choose a service").max(120),
  message: z
    .string()
    .trim()
    .min(12, "A sentence or two about the site helps us quote properly")
    .max(4000),
});

export type SubmitResult = {
  ok: boolean;
  reference: string;
  duplicate: boolean;
  emailsPending: boolean;
  emailNotice: string | null;
};

/** Every protected handler below re-checks the role server-side. */
function requireAdmin(isAdmin: boolean) {
  if (!isAdmin) {
    throw new Response("This account doesn't have access to the quote inbox.", {
      status: 403,
    });
  }
}

function emailOf(claims: unknown): string | null {
  const value = (claims as Record<string, unknown> | undefined)?.["email"];
  return typeof value === "string" ? value : null;
}

/** Public: anyone on the site can submit. Duplicate-safe by request key. */
export const submitQuoteRequest = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => submitShape.parse(input))
  .handler(async ({ data }): Promise<SubmitResult> => {
    const { storeQuoteRequest, deliverQuoteEmails } = await import(
      "./quote.server"
    );

    const { row, duplicate } = await storeQuoteRequest(data);
    const outcome = await deliverQuoteEmails(row);

    return {
      ok: true,
      reference: row.request_key.slice(0, 8).toUpperCase(),
      duplicate,
      emailsPending: !outcome.ownerSent || !outcome.submitterSent,
      emailNotice: outcome.error,
    };
  });

/** Tells the header whether to show the quote inbox link. */
export const getStaffAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    return { isAdmin: !error && Boolean(data) };
  });

export const listQuoteRequests = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: role, error: roleError } = await context.supabase.rpc(
      "has_role",
      { _user_id: context.userId, _role: "admin" },
    );
    requireAdmin(!roleError && Boolean(role));

    const { data, error } = await context.supabase
      .from("quote_requests")
      .select(
        "id, request_key, name, company, email, phone, service, message, status, follow_up_note, owner_email_sent, submitter_email_sent, email_error, handled_at, created_at",
      )
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw error;
    return data;
  });

const statusShape = z.object({
  id: z.string().uuid(),
  status: z.enum(["new", "contacted", "site_visit", "quoted", "closed"]),
  note: z.string().trim().max(2000),
});

const STATUS_LABELS: Record<string, string> = {
  new: "New",
  contacted: "Contacted",
  site_visit: "Site visit booked",
  quoted: "Quoted",
  closed: "Closed",
};

export const updateQuoteRequest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => statusShape.parse(input))
  .handler(async ({ data, context }) => {
    const { data: role, error: roleError } = await context.supabase.rpc(
      "has_role",
      { _user_id: context.userId, _role: "admin" },
    );
    requireAdmin(!roleError && Boolean(role));

    const before = await context.supabase
      .from("quote_requests")
      .select("name, status")
      .eq("id", data.id)
      .maybeSingle();
    if (before.error) throw before.error;
    if (!before.data)
      throw new Response("Request not found", { status: 404 });

    const { error } = await context.supabase
      .from("quote_requests")
      .update({
        status: data.status,
        follow_up_note: data.note,
        handled_at:
          data.status === "new"
            ? null
            : new Date().toISOString().replace("T", " ").slice(0, 19),
      })
      .eq("id", data.id);
    if (error) throw error;

    const { recordActivity } = await import("./quote.server");
    await recordActivity({
      actorId: context.userId,
      actorEmail: emailOf(context.claims),
      action: "quote_status_change",
      detail: `${before.data.name}: ${STATUS_LABELS[before.data.status] ?? before.data.status} → ${STATUS_LABELS[data.status]}`,
    });

    return { ok: true };
  });

const resendShape = z.object({ id: z.string().uuid() });

/** Retry-safe: only the emails that never went out are attempted again. */
export const resendQuoteEmails = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => resendShape.parse(input))
  .handler(async ({ data, context }) => {
    const { data: role, error: roleError } = await context.supabase.rpc(
      "has_role",
      { _user_id: context.userId, _role: "admin" },
    );
    requireAdmin(!roleError && Boolean(role));

    const { loadQuoteRequest, deliverQuoteEmails, recordActivity } =
      await import("./quote.server");
    const row = await loadQuoteRequest(data.id);
    if (!row) throw new Response("Request not found", { status: 404 });

    const outcome = await deliverQuoteEmails(row);
    await recordActivity({
      actorId: context.userId,
      actorEmail: emailOf(context.claims),
      action: "quote_emails_resent",
      detail: `${row.name}${outcome.error ? ` — still blocked: ${outcome.error}` : " — emails sent"}`,
    });
    return outcome;
  });

const activityShape = z.object({
  action: z.enum([
    "staff_sign_in",
    "staff_sign_out",
    "password_reset",
    "account_created",
  ]),
  detail: z.string().trim().max(300).optional(),
});

/** Records account actions. The person and their email come from the verified session. */
export const logStaffActivity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => activityShape.parse(input))
  .handler(async ({ data, context }) => {
    const { recordActivity } = await import("./quote.server");
    await recordActivity({
      actorId: context.userId,
      actorEmail: emailOf(context.claims),
      action: data.action,
      detail: data.detail ?? null,
    });
    return { ok: true };
  });

/** Admin-only activity trail, newest first. */
export const listStaffActivity = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: role, error: roleError } = await context.supabase.rpc(
      "has_role",
      { _user_id: context.userId, _role: "admin" },
    );
    requireAdmin(!roleError && Boolean(role));

    const { data, error } = await context.supabase
      .from("admin_activity")
      .select("id, actor_email, action, detail, created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw error;
    return data;
  });
