type ClassValue =
  | string
  | number
  | boolean
  | null
  | undefined
  | ClassValue[]
  | { [key: string]: boolean | null | undefined };

function clsx(...inputs: ClassValue[]): string {
  const classes: string[] = [];

  for (const input of inputs) {
    if (!input) continue;
    if (Array.isArray(input)) {
      classes.push(clsx(...input));
    } else if (typeof input === "object") {
      for (const [name, enabled] of Object.entries(input)) {
        if (enabled) classes.push(name);
      }
    } else {
      classes.push(String(input));
    }
  }

  return classes.filter(Boolean).join(" ");
}
export function cn(...inputs: ClassValue[]) {
  return clsx(...inputs);
}
