import { sendLovableEmail } from "@lovable.dev/email-js";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { Database } from "@/integrations/supabase/types";

/** Writes one entry to the staff activity trail. */
export async function recordActivity(entry: {
  actorId: string;
  actorEmail: string | null;
  action: string;
  detail: string | null;
}): Promise<void> {
  await supabaseAdmin.from("admin_activity").insert({
    actor_id: entry.actorId,
    actor_email: entry.actorEmail,
    action: entry.action,
    detail: entry.detail,
  });
}

export type QuoteRow =
  Database["public"]["Tables"]["quote_requests"]["Row"];

export type EmailOutcome = {
  ownerSent: boolean;
  submitterSent: boolean;
  error: string | null;
};

export type NewQuote = {
  requestKey: string;
  name: string;
  company?: string | undefined;
  email: string;
  phone: string;
  service: string;
  message: string;
};

const RESPONSE_TIME = "within 1 business day";

function describeError(error: unknown): string {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  return "Unknown delivery failure";
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function plainLines(row: QuoteRow): string {
  return [
    `Name: ${row.name}`,
    row.company ? `Company: ${row.company}` : null,
    `Email: ${row.email}`,
    `Phone: ${row.phone}`,
    `Service: ${row.service}`,
    "",
    "Message:",
    row.message,
  ]
    .filter((line): line is string => line !== null)
    .join("\n");
}

function wrapped(html: string): string {
  return `<div style="font-family:Arial,Helvetica,sans-serif;background:#1a1a1a;color:#f5f5f5;padding:32px">
  <div style="max-width:560px;margin:0 auto;background:#232323;border:1px solid #3a3a3a;padding:28px">
    <p style="margin:0 0 4px;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:#e85d3a">Lebo Security</p>
    ${html}
    <p style="margin:28px 0 0;font-size:12px;color:#a3a3a3">Lebo Security &middot; Gauteng &middot; hello@lebosecurity.co.za</p>
  </div>
</div>`;
}

/** Sends whatever hasn't gone out yet, then records the result on the row. */
export async function deliverQuoteEmails(
  row: QuoteRow,
): Promise<EmailOutcome> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  const senderDomain = process.env["SENDER_DOMAIN"];

  if (!apiKey || !senderDomain) {
    const reason =
      "Email sending isn't active on this site yet — a sender domain has to be verified first. The request is stored and can be re-sent once email is live.";
    await supabaseAdmin
      .from("quote_requests")
      .update({ email_error: reason })
      .eq("id", row.id);
    return { ownerSent: false, submitterSent: false, error: reason };
  }

  let ownerSent = row.owner_email_sent;
  let submitterSent = row.submitter_email_sent;
  const problems: string[] = [];

  if (!ownerSent) {
    try {
      await sendLovableEmail(
        {
          to: process.env["QUOTE_INBOX_EMAIL"] ?? "hello@lebosecurity.co.za",
          from: `Lebo Security <quotes@${senderDomain}>`,
          sender_domain: senderDomain,
          subject: `New quote request — ${row.service} — ${row.name}`,
          html: wrapped(
            `<h2 style="margin:14px 0 6px;font-size:20px">New quote request</h2>
             <p style="margin:0 0 18px;font-size:14px;color:#a3a3a3">Received ${new Date(row.created_at).toLocaleString("en-ZA")}</p>
             <table style="width:100%;font-size:14px;border-collapse:collapse">
               <tr><td style="padding:6px 0;color:#a3a3a3;width:110px">Name</td><td style="padding:6px 0">${escapeHtml(row.name)}</td></tr>
               <tr><td style="padding:6px 0;color:#a3a3a3">Company</td><td style="padding:6px 0">${escapeHtml(row.company ?? "—")}</td></tr>
               <tr><td style="padding:6px 0;color:#a3a3a3">Email</td><td style="padding:6px 0">${escapeHtml(row.email)}</td></tr>
               <tr><td style="padding:6px 0;color:#a3a3a3">Phone</td><td style="padding:6px 0">${escapeHtml(row.phone)}</td></tr>
               <tr><td style="padding:6px 0;color:#a3a3a3">Service</td><td style="padding:6px 0">${escapeHtml(row.service)}</td></tr>
             </table>
             <p style="margin:18px 0 6px;font-size:14px;color:#a3a3a3">Message</p>
             <p style="margin:0;font-size:14px;white-space:pre-wrap">${escapeHtml(row.message)}</p>`,
          ),
          text: `New quote request\n\n${plainLines(row)}`,
          purpose: "quote_request",
          idempotency_key: `${row.request_key}:owner`,
        },
        { apiKey, idempotencyKey: `${row.request_key}:owner` },
      );
      ownerSent = true;
    } catch (error) {
      problems.push(`Business notification: ${describeError(error)}`);
    }
  }

  if (!submitterSent) {
    try {
      await sendLovableEmail(
        {
          to: row.email,
          from: `Lebo Security <quotes@${senderDomain}>`,
          sender_domain: senderDomain,
          subject: `We received your enquiry — Lebo Security`,
          html: wrapped(
            `<h2 style="margin:14px 0 6px;font-size:20px">We have your enquiry</h2>
             <p style="margin:0;font-size:14px">Thank you, ${escapeHtml(row.name)}. A supervisor will review your request for <strong>${escapeHtml(row.service)}</strong> and respond ${RESPONSE_TIME}.</p>
             <p style="margin:18px 0 0;font-size:14px;color:#a3a3a3">Reference ${row.request_key.slice(0, 8)}. If it's urgent, call the number on our contact page.</p>`,
          ),
          text: `We have your enquiry\n\nThank you, ${row.name}. A supervisor will review your request for ${row.service} and respond ${RESPONSE_TIME}.\n\nReference ${row.request_key.slice(0, 8)}.`,
          purpose: "quote_confirmation",
          idempotency_key: `${row.request_key}:submitter`,
        },
        { apiKey, idempotencyKey: `${row.request_key}:submitter` },
      );
      submitterSent = true;
    } catch (error) {
      problems.push(`Confirmation email: ${describeError(error)}`);
    }
  }

  const error = problems.length ? problems.join(" | ") : null;
  await supabaseAdmin
    .from("quote_requests")
    .update({
      owner_email_sent: ownerSent,
      submitter_email_sent: submitterSent,
      email_error: error,
    })
    .eq("id", row.id);

  return { ownerSent, submitterSent, error };
}

/**
 * Stores a request. Safe to call twice with the same key: the second call
 * returns the stored row instead of creating a duplicate.
 */
export async function storeQuoteRequest(
  input: NewQuote,
): Promise<{ row: QuoteRow; duplicate: boolean }> {
  const payload = {
    request_key: input.requestKey,
    name: input.name,
    company: input.company || null,
    email: input.email,
    phone: input.phone,
    service: input.service,
    message: input.message,
  };

  const inserted = await supabaseAdmin
    .from("quote_requests")
    .insert(payload)
    .select()
    .single();

  if (!inserted.error && inserted.data) {
    return { row: inserted.data, duplicate: false };
  }

  // Unique-key violation means the browser retried a request we already saved.
  const existing = await supabaseAdmin
    .from("quote_requests")
    .select()
    .eq("request_key", input.requestKey)
    .maybeSingle();

  if (existing.error) throw existing.error;
  if (!existing.data) throw inserted.error ?? new Error("Save failed");

  return { row: existing.data, duplicate: true };
}

export async function loadQuoteRequest(id: string): Promise<QuoteRow | null> {
  const { data } = await supabaseAdmin
    .from("quote_requests")
    .select()
    .eq("id", id)
    .maybeSingle();
  return data ?? null;
}
