import accessControl from "@/assets/access-control.jpg";
import alarmResponse from "@/assets/alarm-response.jpg";
import cctvInstallation from "@/assets/cctv-installation.jpg";
import eventCrowd from "@/assets/event-crowd.jpg";
import executiveLobby from "@/assets/executive-lobby.jpg";
import loadingBayCheck from "@/assets/loading-bay-check.jpg";
import patrolVehicle from "@/assets/patrol-vehicle.jpg";

export type Service = {
  slug: string;
  title: string;
  shortTitle: string;
  benefit: string;
  blurb: string;
  includes: string[];
  image: string;
  alt: string;
};

/** The four headline services: each gets its own section, benefit and CTA. */
export const SERVICES: Service[] = [
  {
    slug: "guarding",
    title: "Manned guarding",
    shortTitle: "Guarding",
    benefit: "Deterrence you can prove",
    blurb:
      "Vetted officers on your gate, in your lobby or walking your perimeter — briefed on your site rules in writing before their first shift, not after an incident.",
    includes: [
      "Gatehouse, lobby and critical-point cover",
      "Arm and hand-over checks at every shift change",
      "Visitor and contractor register kept current",
      "Occurrence book plus a written daily shift report",
    ],
    image: loadingBayCheck,
    alt: "Security officer inspecting a warehouse roller door with a torch at night",
  },
  {
    slug: "cctv-installation",
    title: "CCTV installation & monitoring",
    shortTitle: "CCTV installation",
    benefit: "Footage that holds up",
    blurb:
      "Cameras placed where the light and the traffic actually are, installed by our own technicians, then watched by operators instead of left to record a hard drive nobody opens.",
    includes: [
      "Site survey and camera placement plan before we quote",
      "Supply and install dome, bullet and ANPR cameras",
      "Recorder, cabling and remote app access handed over with training",
      "Live monitoring, alarm verification and clip retrieval on request",
    ],
    image: cctvInstallation,
    alt: "Technician installing a dome CCTV camera on a concrete wall at dusk",
  },
  {
    slug: "access-control",
    title: "Access control",
    shortTitle: "Access control",
    benefit: "You know who came and went",
    blurb:
      "Cards, biometrics and boom gates that log every entry and lock the wrong person out before they reach the door — with permissions you can change the same afternoon.",
    includes: [
      "Card, fob and biometric enrollment and instant de-activation",
      "Time-based permissions per door, zone and shift",
      "Boom gate, intercom and turnstile integration",
      "Monthly access audit with a leaver report",
    ],
    image: accessControl,
    alt: "Hand holding a key fob against a wall-mounted access control reader",
  },
  {
    slug: "alarm-response",
    title: "Alarm response",
    shortTitle: "Alarm response",
    benefit: "Someone answers besides you",
    blurb:
      "When the panel fires at 02:00, a vehicle is already assigned. They verify what happened, secure the site and write it down — instead of ringing you to ask.",
    includes: [
      "Armed and unarmed reaction vehicles held on standby",
      "Verification before escalation, with photo evidence attached",
      "Key-hold service and on-site securing of open buildings",
      "Incident report ready for your insurer or the police",
    ],
    image: alarmResponse,
    alt: "Armed responder stepping out of a reaction vehicle at night",
  },
];

/** Supporting services, listed on the home page and detailed on /services. */
export const OTHER_SERVICES: Service[] = [
  {
    slug: "mobile-patrols",
    title: "Mobile patrols",
    shortTitle: "Mobile patrols",
    benefit: "Routes nobody can learn",
    blurb:
      "Marked and unmarked vehicles running randomised rounds, logging every checkpoint scan so a gap in cover is visible to you the same night it happens.",
    includes: [
      "Randomised patrol times so patterns cannot be learned",
      "GPS-stamped checkpoint scans on every round",
      "Photo evidence attached to each outside check",
      "Same-night escalation for damage, open gates or failed locks",
    ],
    image: patrolVehicle,
    alt: "Security patrol vehicle parked in a fenced industrial yard at dusk",
  },
  {
    slug: "event-security",
    title: "Event security",
    shortTitle: "Event security",
    benefit: "Calm queues, fewer incidents",
    blurb:
      "Crowd management, accreditation and gate control for venues, launches and film sets — from a single steward to a full radio-controlled deployed team.",
    includes: [
      "Access lanes, accreditation and bag checks",
      "Counter and radio-controlled deployment",
      "Conflict management trained supervisors",
      "Load-in, show and load-out cover in one contract",
    ],
    image: eventCrowd,
    alt: "Uniformed stewards managing a guest queue at a venue entrance at night",
  },
  {
    slug: "executive-protection",
    title: "Executive protection",
    shortTitle: "Executive protection",
    benefit: "Discreet, planned movements",
    blurb:
      "Close protection for travel, residential security and high-risk movements — planned quietly with you beforehand and reviewed confidentially afterwards.",
    includes: [
      "Route and venue planning before the movement",
      "Officers trained in first aid and defensive driving",
      "Discreet residential and travel cover",
      "Confidentiality agreements signed by every officer",
    ],
    image: executiveLobby,
    alt: "Close protection officer walking with a client through a glass office lobby",
  },
];

export const ALL_SERVICES: Service[] = [...SERVICES, ...OTHER_SERVICES];
